﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estructura_if
{
    class Program
    {
        static void Main(string[] args)
        {
            //Estructura if

            byte x = 20, y = 19, z = 25;

            if (x > y)
            {
                if (z > x)
                {
                    Console.WriteLine("z es el mayor de todos");
                }
            }
        }
    }
}